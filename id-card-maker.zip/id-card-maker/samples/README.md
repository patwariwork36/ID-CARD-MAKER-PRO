# Sample Data

This folder contains sample files to test the bulk import feature.

## Files

- **sample_data.csv** — Sample employee data (3 people). Open in Excel and **Save As → .xlsx** to use with the bulk import.

## Photos format

Create a folder called `photos/` and add JPG/PNG files named after the employee codes:

```
photos/
├── EMP001.jpg
├── EMP002.jpg
└── EMP003.jpg
```

Then ZIP the folder and upload via the **Photos ZIP** field.

## Testing workflow

1. Open `sample_data.csv` in Excel → Save as `sample_data.xlsx`
2. Add 3 dummy passport-style photos named `EMP001.jpg`, `EMP002.jpg`, `EMP003.jpg`
3. Right-click the photos folder → Send to → Compressed (ZIP) folder
4. Open `index.html` → expand **📦 Bulk Import**
5. Upload Excel + ZIP → click **Import Bulk Data**
6. See 3 cards generated instantly!
