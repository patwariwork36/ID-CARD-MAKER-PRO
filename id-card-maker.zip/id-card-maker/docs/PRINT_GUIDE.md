# 🖨️ Print Guide — ID Card Maker Pro

Detailed instructions for getting professional results when printing your ID cards.

---

## 📐 Card Dimensions

The tool generates cards in standard **CR80** size:
- **Portrait:** 54mm × 85.6mm (2.13" × 3.38")
- **Landscape:** 85.6mm × 54mm (3.38" × 2.13")

These are the same dimensions as a credit card / Aadhaar card — perfect for lanyards, wallets, and ID holders.

---

## 🎯 Print Setup (Browser)

### Chrome / Edge (Recommended)
1. Press **Ctrl + P** (Cmd + P on Mac)
2. Click **More settings** to expand
3. Configure:
   - **Destination:** Your printer (or Save as PDF)
   - **Pages:** All
   - **Layout:** Portrait (matches card orientation)
   - **Color:** Color
   - **Paper size:** A4 (or Custom 54×86mm if your printer supports it)
   - **Pages per sheet:** 1
   - **Margins:** None ⚠️ Important
   - **Scale:** 100% (Default) ⚠️ Critical — DO NOT use "Fit to page"
   - **Background graphics:** ✅ ON (under "More settings")
   - **Headers and footers:** OFF

### Firefox
1. Press Ctrl + P
2. Click "More settings"
3. Same as Chrome — focus on **100% scale, no margins, print backgrounds**.

---

## 📄 Paper Recommendations

| Paper Type | GSM | Use Case |
|---|---|---|
| Glossy photo paper | 200–230 | Color-rich cards, photos pop |
| Matte cardstock | 230–280 | Professional, no glare |
| PVC sheets | — | Final laminated cards |
| Standard A4 (printable proofs) | 80–100 | Drafts only |

For **production**, print on **PVC ID card sheets** that go into card printers, or laminate on cardstock.

---

## 🔪 Cutting

After printing on A4:

### With paper cutter (best)
- Use a **rotary trimmer** with measurement guide
- Set to 54mm or 86mm depending on orientation
- Cut along the hairline borders

### With scissors
- Use a steel ruler as guide
- Cut just inside the hairline border for clean edges

### With laminator (recommended)
1. Cut cards to size first
2. Insert into A6 / ID-card laminating pouches
3. Run through laminator at appropriate setting
4. Trim off excess pouch around edges

---

## 🖨️ Specialized ID Card Printers

For professional issuance at scale, consider:
- **Evolis Primacy 2** — single-side / dual-side
- **Zebra ZC100/ZC300** — standard government deployments
- **Magicard Rio Pro 360** — high-end

These printers expect specific image dimensions. Export your cards as **PDF at 100%** scale and the printer driver will handle the rest.

---

## 🐛 Common Issues

### Cards print too small
- ❌ "Fit to page" is enabled
- ✅ Set Scale to **100%** or **Actual Size**

### Colors look faded
- ❌ "Background graphics" disabled
- ✅ Enable in print settings

### Hindi text shows as boxes
- ❌ System missing Devanagari font
- ✅ The tool loads Noto Sans Devanagari from Google Fonts — connect to internet once, then it caches

### Borders cut off
- ❌ Margin enabled
- ✅ Set margins to **None** or **Default → minimum**

### Photo is blurry
- ❌ Source image too small
- ✅ Use minimum **300×400 px** photos for crisp 54×72mm prints

---

## 💡 Pro Tips

1. **Test on regular paper first** before using expensive PVC
2. **Print one A4 sheet of 6 cards** to check alignment, then scale up
3. **Save as PDF** as backup — useful for sending to print shops
4. **Keep a "master" profile** with logo + signature + theme so you only need to add new people each time
5. **Photos:** Use **passport-style** portraits (face fills 70% of frame, plain background)

---

## 📞 Need Help?

Open an issue on GitHub or check the README.
